function istprimzahl = PrimzahlCheck(testzahl)

istprimzahl = [];

end
