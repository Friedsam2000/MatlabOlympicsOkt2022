function output = plotCollatz(input)
    
    % Definition der Variablen, die nötig sind, damit das Code läuft
    ergebnisse = input;
    bedingung = true;
    schrittzahl = 0;
    
    while bedingung  % Diese Schleife wird durchgeführt, solang bedingung true ist
        
        schrittzahl = schrittzahl + 1;
        
        % Die Schrittzahl brauchen wir, damit wir die Ergebnisse in einem
        % Vektor speichern können. Bspw. ist die Zahl in 
        % ergebnisse(3) das Ergebnis von dem dritten Schritt.
        
        if ergebnisse(schrittzahl) == 1
            bedingung = false; % Wenn letzte Zahl = 1, Schleife beenden
            break
        elseif mod(---------------) == 0 % Hier seid ihr dran
            ergebnisse(schrittzahl+1) =                         ; % Hier seid ihr dran
        elseif mod(---------------) == 1 % Hier seid ihr dran
            ergebnisse(schrittzahl+1) =                         ; % Hier seid ihr dran
        end
    end
    plot(1:schrittzahl,ergebnisse) % Graph plotten
    output =            ; % Hier seid ihr dran
end
