function durchschnitt = gruppenalter(vektor_alter)

durchschnitt = [];

end 
 
