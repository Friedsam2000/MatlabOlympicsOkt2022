function plotTUMLogo()

    % Plottet das TUM-Logo in seiner vollen Exzellenz mit
    % Eckpunktkoordinaten und einer nachfolgenden Extrusion in die 
    % dritte Dimension.

    % 2D-Koordinaten laden
    load('tumdata.csv');
    % Die Seitenflächen und Eckpunkte des 3D-Logos rechnen
    polygon3D = extrude_vertices(tumdata, 0, 1);
    % Logo plotten
    patch('Faces', polygon3D.faces,'Vertices', polygon3D.vertices, ...
        'FaceColor', [0 101/255 189/255], 'EdgeColor', 'black', ...
        'LineWidth', 2);
    % Faces sind die Seitenflächen, Vertices die Eckpunkte.
    % FaceColor beschreibt den TUM-Blau in RGB-Werten, wobei 255 das
    % Maximum für eine jeweilige Farbe ist.
    
    % Ansicht definieren
    zlim([-5 5]); % Limit Z-Koordinate
    xlim([-100 900]); % Limit X-Koordinate
    view(30,50); % Ansicht definieren
    
end