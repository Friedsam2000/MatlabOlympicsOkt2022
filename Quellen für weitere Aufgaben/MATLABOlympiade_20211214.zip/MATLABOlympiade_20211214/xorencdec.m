function [output] = xorencdec(text, key)
    
%     Quelle:
%     https://stackoverflow.com/questions/21229978/how-to-perform-xor-cipher-in-matlab
%     
%     Verschlüsselt oder entschlüsselt einen gegebenen String mit einem Key
%     mittels XOR 
%     Verwendung: output = xorencdec(text, key) wobei text und
%     key beide Strings sind.
    
    output = char(bitxor(text+0, key(mod(0:numel(text+0)-1, numel(key+0))+1)+0));
    
end