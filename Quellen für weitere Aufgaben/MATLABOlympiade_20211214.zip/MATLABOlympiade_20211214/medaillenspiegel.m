function medals_table = medaillenspiegel()    
    %% Frage
    % Ihr müsst den Medaillenspiegel in der richtigen Reihenfolge auf die Olympischen Spiele setzen. 
    % Um die Tabelle zu ordnen, sortiert ihr zuerst die Goldmedaillen, dann die Silbermedaillen und schließlich die Bronzemedaillen.

    % Tipp: 
    % Ihr könnt eine Tabelle nach einer bestimmten Variablen sortieren, indem ihr die Funktion sortrows verwendet.
    % Standardmäßig gibt diese Funktion die Werte in aufsteigender Reihenfolge zurück. Ihr könnt die Option "descend" verwenden, um in absteigender Reihenfolge zu sortieren.
    % Um nach zwei oder mehr Variablen zu sortieren, gebt ihr diese in der Reihenfolge der Funktion sortrows als Array an.
    % Zum Beispiel: tSort = sortrows(tableName,["var1" "var2"],"descend")


    %% Aufgabe
    % Vorgegeben
    CountryName = ["AUS"; "CHN"; "FRA"; "GBR"; "GER"; "ITA"; "JPN"; "NED"; "ROC"; "USA"];
    GoldMedal = [17; 38; 10; 22; 10; 10; 27; 10; 20; 39];
    SilverMedal = [7; 32; 12; 21; 11; 10; 14; 12; 28; 41];
    BronzeMedal = [22; 18; 11; 22; 16; 20; 17; 14; 23; 33];
    raw_medals_table = table(CountryName,GoldMedal,SilverMedal,BronzeMedal);


    % Lösung
    medals_table = [];
end