function checkDetectedObject(value)
% !!!! p-code this file before distributing !!!!

if strcmpi(value, 'ballpoint')
    fprintf('Object 1 has been detected. Keyword: vfc\n')
elseif contains(value, 'cup') || contains(value, 'mug')
    fprintf('Object 2 has been detected. Key: pkg\n');
elseif contains(value, 'shoe')
    fprintf('Object 3 has been detected. Key: qnh\n');
elseif contains(value, 'bottle')
    fprintf('Object 4 has been detected. Key: euy\n')
else
    fprintf('No required object has been detected.\n')
end

end