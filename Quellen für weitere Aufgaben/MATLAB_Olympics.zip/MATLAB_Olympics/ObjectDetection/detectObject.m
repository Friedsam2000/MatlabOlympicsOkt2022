clear;
m = mobiledev;
cam = camera(m,'back');

% Load pretrained neural network
nnet = googlenet;

% Take a picture and display it
img = snapshot(cam,'manual');
pic = imresize(img,[224,224]);
image(pic)

% Classify
value = classify(nnet,pic);
title(char(value))

fprintf('Detected object:\t%s\n', value);
checkDetectedObject(char(value));