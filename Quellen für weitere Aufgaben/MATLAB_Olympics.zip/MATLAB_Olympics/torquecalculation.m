function torque = torquecalculation(force, distance)

torque = []; % overwrite

end 