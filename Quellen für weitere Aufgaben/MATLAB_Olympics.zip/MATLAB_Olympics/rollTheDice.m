function pip_sum = rollTheDice(num_dice,num_faces)

pip_sum = []; % Overwrite

end 