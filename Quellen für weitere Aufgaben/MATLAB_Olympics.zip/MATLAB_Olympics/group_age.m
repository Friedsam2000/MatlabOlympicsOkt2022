function av_age = group_age(age_vector)

av_age = []; % overwrite

end