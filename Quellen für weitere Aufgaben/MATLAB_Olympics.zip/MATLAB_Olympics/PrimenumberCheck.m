function isprimenumber = PrimenumberCheck(testnumber)

isprimenumber = []; % overwrite

end 

