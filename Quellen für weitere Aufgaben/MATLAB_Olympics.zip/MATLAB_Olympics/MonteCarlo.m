function [mean_approx,standarddev_approx] = MonteCarlo(mean_given,standarddev_given)
%% 1) Create a normal distribution "pd" with given mean and standard deviation
% Command: makedist (-> doc makedist ) 



%% 2) Create a for-loop and draw 10000 times from that distribution
% Command: sample = random(pd)
% Store all samples in a vector



%% 3) Compute the mean and standard deviation of this vector using MATLAB-functions

mean_approx = []; % overwrite
standarddev_approx = []; % overwrite

end