function scrambled = WordScramble(word)

scrambled = []; % overwrite

end 