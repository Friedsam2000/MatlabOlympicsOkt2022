function functionCheck()
% !!!! p-code this file before distributing !!!!

%% Problem 1
try
    if plusOne(5) == 6
        fprintf('\tProblem 1 (Add One):\t\tcorrect\n')
    else
        fprintf('\tProblem 1 (Add One):\t\twrong\n');
    end
catch
    fprintf('\tProblem 1 (Add One):\t\twrong\n');
end

%% Problem 2
try
    if group_age([23, 33, 43]) == mean([23, 33, 43])
        fprintf('\tProblem 2 (Average Age):\tcorrect\n');
    else
        fprintf('\tProblem 2 (Average Age):\twrong\n');
    end
catch
    fprintf('\tProblem 2 (Average Age):\twrong\n');
end

%% Problem 3
try
    sum1 = rollTheDice(4,10);
    sum2 = rollTheDice(4,10);
    sum3 = rollTheDice(4,10);
    if (sum1 ~= sum2 || sum2 ~= sum3) && min([sum1,sum2,sum3]) >= 4 && max([sum1,sum2,sum3]) <= 4*10
        fprintf('\tProblem 3 (Roll the Dice):\tcorrect\n');
    else
        fprintf('\tProblem 3 (Roll the Dice):\twrong\n');
    end
catch
    fprintf('\tProblem 3 (Roll the Dice):\twrong\n');
end

%% Problem 4

force = [1,2,3];
distance = [1,4,1];

try
    if all(reshape(torquecalculation(force, distance), 1, []) == cross(distance, force))
        fprintf('\tProblem 4 (Mechanics):\t\tcorrect\n');
    else
        fprintf('\tProblem 4 (Mechanics):\t\twrong\n');
    end
catch
    fprintf('\tProblem 4 (Mechanics):\t\twrong\n');
end

%% Problem 5
try
    if PrimenumberCheck(13) && ~PrimenumberCheck(4)
        fprintf('\tProblem 5 (Prime Numbers):\tcorrect\n');
    else
        fprintf('\tProblem 5 (Prime Numbers):\twrong\n');
    end
catch
    fprintf('\tProblem 5 (Prime Numbers):\twrong\n');
end

%% Problem 6
try
    scrambled = wordscramble('CultureOfExcellence');
    if ~strcmp(scrambled, 'CultureOfExcellence') && strcmp(sort(scrambled), sort('CultureOfExcellence'))
        fprintf('\tProblem 6 (Word Scramble):\tcorrect\n');
    else
        fprintf('\tProblem 6 (Word Scramble):\twrong\n');
    end
catch
    fprintf('\tProblem 6 (Word Scramble):\twrong\n');
end


%% Problem 7
try
    mean_given = 10;
    standarddev_given = 2;
    rng(10);
    [mean_approx,standarddev_approx] = MonteCarlo(mean_given,standarddev_given);
    
    if abs(mean_given-mean_approx) < 0.1 && abs(standarddev_given-standarddev_approx) < 0.1 && mean_given ~= mean_approx && standarddev_given ~= standarddev_approx
        fprintf('\tProblem 7 (Monte Carlo):\tcorrect\n');
    else
        fprintf('\tProblem 7 (Monte Carlo):\twrong\n');
    end
catch
    fprintf('\tProblem 7 (Monte Carlo):\twrong\n');
end

%% Problem 9

try
    keyword = evalin('base', 'keyword');
    
    if strcmp(keyword, 'vfcpkgqnheuy')
        fprintf('\tProblem 9 (Object Detection):\tcorrect\n');
    else
        fprintf('\tProblem 9 (Object Detection):\twrong\n');
    end
catch
    fprintf('\tProblem 9 (Object Detection):\twrong\n');
end
