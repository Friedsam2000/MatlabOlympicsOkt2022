function Augensumme = rollTheDice(AnzahlWuerfel,AnzahlSeiten)

Augensumme = []; % überschreiben

end 