function requiredTerms = taylorseries(x)

requiredTerms = [];

end