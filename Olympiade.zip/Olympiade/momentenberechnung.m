function moment = momentenberechnung(kraft, hebelarm)


moment = []; % überschreiben

end 