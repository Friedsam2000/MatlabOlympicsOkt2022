function n = taylorseries(x)

n = [];

end