function vierplots()
    figure
    
    % TODO
    x_a = [];
    y_a = [];
    %
    subplot(2,2,1);
    plot(x_a,y_a,'b.-'), grid on, title('(a)')
    
    % TODO
    x_b = [];
    y_b = [];
    %
    subplot(2,2,2);
    plot(x_b,y_b,'b.-'), grid on, title('(b)')
    
    % TODO
    x_c = [];
    y_c = [];
    %
    subplot(2,2,3);
    plot(x_c,y_c,'b.-'), grid on, title('(c)')

    % TODO
    x_d = [];
    y_d = [];
    %
    subplot(2,2,4);
    plot(x_d,y_d,'b.-'), grid on, title('(d)')

end