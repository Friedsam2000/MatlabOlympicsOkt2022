function istprimzahl = PrimzahlCheck(testzahl)


istprimzahl = []; % überschreiben

end 

